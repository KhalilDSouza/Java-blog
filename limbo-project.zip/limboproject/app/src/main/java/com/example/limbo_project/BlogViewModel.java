package com.example.limbo_project;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class BlogViewModel extends AndroidViewModel {
    private final BlogRepository blogRepository;
    private LiveData<List<Blog>> allBlogs;

    public BlogViewModel(Application application) {
        super(application);
        blogRepository = new BlogRepository(application);
        allBlogs = blogRepository.getAllBlogs();
    }

    public LiveData<List<Blog>> getAllBlogs() {
        return allBlogs;
    }

    public void insert(Blog blog) {
        blogRepository.insert(blog);
    }
}
