package com.example.limbo_project;

import android.app.Application;
import android.os.AsyncTask;
import androidx.lifecycle.LiveData;
import java.util.List;

public class BlogRepository {
    private BlogDao blogDao;
    private LiveData<List<Blog>> allBlogs;

    public BlogRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        blogDao = db.blogDao();
    }

    public LiveData<List<Blog>> getAllBlogs() {
        return allBlogs;
    }

    public void insert(Blog blog) {
        new InsertAsyncTask(blogDao).execute(blog);
    }

    private static class InsertAsyncTask extends AsyncTask<Blog, Void, Void> {
        private BlogDao blogDao;

        InsertAsyncTask(BlogDao dao) {
            blogDao = dao;
        }

        @Override
        protected Void doInBackground(final Blog... params) {
            blogDao.insert(params[0]);
            return null;
        }
    }
}
