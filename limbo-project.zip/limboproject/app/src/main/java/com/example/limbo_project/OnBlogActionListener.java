package com.example.limbo_project;


public interface OnBlogActionListener {
    void onEditBlog(Blog blog);
    void onDeleteBlog(Blog blog);
}
