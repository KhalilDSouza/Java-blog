package com.example.limbo_project;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "blogs")
public class Blog {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String description;
    private String userId;
    private String username ;

    public Blog(String title, String description, String userId, String username) {
        this.title = title;
        this.description = description;
        this.userId = userId;
        this.username = username;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username; // Getter para o nome do usuário
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
