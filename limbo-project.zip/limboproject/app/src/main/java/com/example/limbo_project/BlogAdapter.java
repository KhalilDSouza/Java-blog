package com.example.limbo_project;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class BlogAdapter extends RecyclerView.Adapter<BlogAdapter.BlogViewHolder> {

    private List<Blog> blogs;
    private OnBlogActionListener listener;


    public BlogAdapter(OnBlogActionListener listener, List<Blog> blogs) {
        this.listener = listener;
        this.blogs = (blogs != null) ? blogs : new ArrayList<>();
    }


    public static class BlogViewHolder extends RecyclerView.ViewHolder {
        TextView textViewUsername;
        TextView textViewTitle;
        TextView textViewDescription;

        public BlogViewHolder(View itemView) {
            super(itemView);
            textViewUsername = itemView.findViewById(R.id.textViewUsername);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
        }
    }

    @NonNull
    @Override
    public BlogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_blog_card, parent, false);
        return new BlogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BlogViewHolder holder, int position) {
        Blog blog = blogs.get(position);
        if (blog != null) {
            holder.textViewTitle.setText(blog.getTitle());
            holder.textViewDescription.setText(blog.getDescription());
            holder.textViewUsername.setText(blog.getUsername() != null ? blog.getUsername() : "@Username 123");


            holder.itemView.findViewById(R.id.buttonEdit).setOnClickListener(v -> {
                listener.onEditBlog(blog);
            });


            holder.itemView.findViewById(R.id.buttonDelete).setOnClickListener(v -> {
                listener.onDeleteBlog(blog);
            });
        }
    }

    @Override
    public int getItemCount() {
        return blogs.size();
    }

    public void setBlogs(List<Blog> blogs) {
        this.blogs = blogs;
        notifyDataSetChanged();
    }
}
