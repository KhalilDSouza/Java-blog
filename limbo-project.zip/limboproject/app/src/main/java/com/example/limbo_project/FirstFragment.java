package com.example.limbo_project;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.limbo_project.databinding.FragmentFirstBinding;
import java.util.List;

public class FirstFragment extends Fragment implements OnBlogActionListener {

    private FragmentFirstBinding binding;
    private BlogAdapter blogAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout using Data Binding
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        binding.recyclerViewBlogs.setLayoutManager(new LinearLayoutManager(getContext()));
        blogAdapter = new BlogAdapter(this, null);
        binding.recyclerViewBlogs.setAdapter(blogAdapter);


        AppDatabase db = AppDatabase.getDatabase(requireContext());


        new Thread(() -> {
            List<Blog> blogs = db.blogDao().getAllBlogs(); // Certifique-se de ter este método no BlogDao
            requireActivity().runOnUiThread(() -> blogAdapter.setBlogs(blogs));
        }).start();


        binding.fabAddBlog.setOnClickListener(v -> showModalDialog(null));
    }

    private void showModalDialog(Blog blog) {

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View modalView = inflater.inflate(R.layout.modal_content, null);


        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setView(modalView); // Usa o layout inflado


        EditText editTextTitle = modalView.findViewById(R.id.editTextTitle);
        EditText editTextDescription = modalView.findViewById(R.id.editTextDescription);

        if (blog != null) {

            editTextTitle.setText(blog.getTitle());
            editTextDescription.setText(blog.getDescription());
        }


        builder.setPositiveButton("Enviar", (dialog, which) -> {
            String title = editTextTitle.getText().toString();
            String description = editTextDescription.getText().toString();
            String user = "user_id"; // Substitua pela lógica para obter o ID do usuário real
            String userName = "@Username 123";


            if (blog == null) {
                Blog newBlog = new Blog(title, description, user, userName);
                insertBlog(newBlog);
            } else {
                blog.setTitle(title);
                blog.setDescription(description);
                updateBlog(blog);
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void insertBlog(Blog newBlog) {
        AppDatabase db = AppDatabase.getDatabase(requireContext());
        new Thread(() -> {
            db.blogDao().insert(newBlog);
            requireActivity().runOnUiThread(() -> {
                updateBlogList();
                Toast.makeText(requireContext(), "Post enviado com Sucesso!", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    private void updateBlog(Blog blog) {
        AppDatabase db = AppDatabase.getDatabase(requireContext());
        new Thread(() -> {
            db.blogDao().update(blog);
            requireActivity().runOnUiThread(() -> {
                updateBlogList();
                Toast.makeText(requireContext(), "Post Editado com Sucesso!", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }


    private void updateBlogList() {
        AppDatabase db = AppDatabase.getDatabase(requireContext());
        new Thread(() -> {
            List<Blog> blogs = db.blogDao().getAllBlogs();
            requireActivity().runOnUiThread(() -> blogAdapter.setBlogs(blogs));
        }).start();
    }

    @Override
    public void onEditBlog(Blog blog) {
        showModalDialog(blog);
    }

    @Override
    public void onDeleteBlog(Blog blog) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirmação")
                .setMessage("Você tem certeza que deseja excluir este blog?")
                .setPositiveButton("Sim", (dialog, which) -> deleteBlog(blog))
                .setNegativeButton("Não", null)
                .show();
    }

    private void deleteBlog(Blog blog) {
        AppDatabase db = AppDatabase.getDatabase(requireContext());
        new Thread(() -> {
            db.blogDao().delete(blog);
            requireActivity().runOnUiThread(() -> {
                updateBlogList();
                Toast.makeText(requireContext(), "Post Deletado com Sucesso!", Toast.LENGTH_SHORT).show();
            });

        }).start();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }
}
