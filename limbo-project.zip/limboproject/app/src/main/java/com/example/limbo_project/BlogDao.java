package com.example.limbo_project;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BlogDao {
    @Insert
    void insert(Blog blog);

    @Update
    void update(Blog blog);

    @Delete
    void delete(Blog blog);

    @Query("SELECT * FROM blogs")
    List<Blog> getAllBlogs();
}

